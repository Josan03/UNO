<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="3"
    stroke-linecap="round"
    stroke-linejoin="round"
    class="w-2/3 h-2/3 text-white"
  >
    <path d="M20 6L9 17l-5-5" />
  </svg>
</template>
