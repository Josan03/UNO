<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
    class="w-2/3 h-2/3 text-white"
  >
    <path d="M5 5v14l7-7zm7 0v14l7-7z" />
  </svg>
</template>
