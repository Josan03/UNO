<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
    class="w-2/3 h-2/3 text-white"
  >
    <path d="M8 5v14l11-7z" />
  </svg>
</template>
