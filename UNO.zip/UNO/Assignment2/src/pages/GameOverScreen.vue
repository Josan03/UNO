<script setup lang="ts"></script>
<template>
  <div>Game Over Screen</div>
</template>
